import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    private static ArrayList<Produto> produtos = new ArrayList<>();
    private static ArrayList<Pedido> pedidos = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);
    private static final String ARQUIVO_PRODUTOS = "produtos.txt";
    private static int numeroPedidoAtual = 0;

    public static void main(String[] args) throws Exception {

        carregarProdutos();
        carregarPedidos();

        while (true) {
            System.out.println("# Menu principal #");
            System.out.println("[1] Produtos");
            System.out.println("[2] Pedidos");
            System.out.println("[3] Sair");
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    menuProdutos();
                    break;
                case 2:
                    menuPedidos();
                    break;
                case 3:
                    salvarProdutos();
                    salvarPedidos();
                    System.out.println("Saindo...");
                    return;
                default:
                    System.out.println("Opção inválida! Tente novamente...");
                    break;
            }
        }
    }

    private static void carregarProdutos() {
        try (BufferedReader reader = new BufferedReader(new FileReader(ARQUIVO_PRODUTOS))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                String[] partes = linha.split(";");
                int codigo = Integer.parseInt(partes[0]);
                String nome = partes[1];
                double preco = Double.parseDouble(partes[2]);
                int quantidade = Integer.parseInt(partes[3]);
                produtos.add(new Produto(codigo, nome, preco, quantidade));
                Produto.setUltimoCodigo(codigo);
            }
        } catch (IOException e) {
            System.out.println("Erro ao carregar produtos: " + e.getMessage());
        }
    }

    private static void salvarProdutos() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ARQUIVO_PRODUTOS))) {
            for (Produto produto : produtos) {
                writer.write(produto.getCodigoProduto() + ";" + produto.getNomeProduto() + ";"
                        + produto.getPrecoUnitario() + ";" + produto.getQuantidadeEstoque());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Erro ao salvar produtos: " + e.getMessage());
        }
    }

    private static void menuProdutos() {
        while (true) {
            System.out.println("# Produtos #");
            System.out.println("[1] Incluir produto");
            System.out.println("[2] Editar quantidade estoque produto");
            System.out.println("[3] Editar preço unitário produto");
            System.out.println("[4] Excluir produto");
            System.out.println("[5] Listagem produtos");
            System.out.println("[6] Voltar ao menu principal");
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    incluirProduto();
                    break;
                case 2:
                    editarQuantidadeEstoqueProduto();
                    break;
                case 3:
                    editarPrecoUnitarioProduto();
                    break;
                case 4:
                    excluirProduto();
                    break;
                case 5:
                    listarProdutos();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Opção inválida! Tente novamente...");
                    break;
            }
        }
    }

    private static void incluirProduto() {
        System.out.print("Nome do produto: ");
        String nome = scanner.nextLine();

        System.out.print("Preço unitário do produto: ");
        double preco = scanner.nextDouble();

        System.out.print("Quantidade em estoque: ");
        int quantidade = scanner.nextInt();

        produtos.add(new Produto(nome, preco, quantidade));
        System.out.println("Produto incluído com sucesso!");
    }

    public static void editarQuantidadeEstoqueProduto() {
        System.out.print("Codigo do produto: ");
        int codigo = scanner.nextInt();
        Produto produto = encontrarProduto(codigo);
        if (produto != null) {
            System.out.print("Nova quantidaade em estoque: ");
            int quantidade = scanner.nextInt();
            produto.setQuantidadeEstoque(quantidade);
            System.out.println("Quantidade em estoque do produto alterada com sucesso!");
        } else {
            System.out.println("Produto não encontrado!");
        }
    }

    private static Produto encontrarProduto(int codigo) {
        for (Produto produto : produtos) {
            if (produto.getCodigoProduto() == codigo) {
                return produto;
            }
        }
        return null;
    }

    private static void editarPrecoUnitarioProduto() {
        System.out.print("Código do produto: ");
        int codigo = scanner.nextInt();
        Produto produto = encontrarProduto(codigo);
        if (produto != null) {
            System.out.print("Novo preço unitário: ");
            double preco = scanner.nextDouble();
            produto.setPrecoUnitario(preco);
            System.out.println("Preço atualizado com sucesso!");
        } else {
            System.out.println("Produto não encontrado!");
        }
    }

    private static void excluirProduto() {
        System.out.print("Código do produto: ");
        int codigo = scanner.nextInt();
        Produto produto = encontrarProduto(codigo);
        if (produto != null) {
            produtos.remove(produto);
            System.out.println("Produto excluído com sucesso!");
        } else {
            System.out.println("Produto não encontrado!");
        }
    }

    private static void listarProdutos() {
        if (produtos.isEmpty()) {
            System.out.println("Nenhum produto cadastrado.");
        } else {
            System.out
                    .println("Código  Nome                                         Preço unitário  Quantidade estoque");
            System.out
                    .println("---------------------------------------------------------------------------------------");
            double valorTotalEstoque = 0.0;
            for (Produto produto : produtos) {
                System.out.printf("%-7d %-48s %12.1f %18d%n",
                        produto.getCodigoProduto(), produto.getNomeProduto(), produto.getPrecoUnitario(),
                        produto.getQuantidadeEstoque());
                valorTotalEstoque += produto.getPrecoUnitario() * produto.getQuantidadeEstoque();
            }
            System.out
                    .println("---------------------------------------------------------------------------------------");
            System.out.printf("Valor total estoque: %.2f%n", valorTotalEstoque);
        }
    }

    private static void menuPedidos() {
        while (true) {
            System.out.println("# Pedidos #");
            System.out.println("[1] Novo pedido");
            System.out.println("[2] Listagem pedidos");
            System.out.println("[3] Voltar ao menu principal");
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    novoPedido();
                    break;
                case 2:
                    listarPedidos();
                    break;
                case 3:
                    return;
                default:
                    System.out.println("Opção inválida! Tente novamente...");
                    break;
            }
        }
    }

    private static void novoPedido() {
        numeroPedidoAtual++;
        int numeroPedido = numeroPedidoAtual;
        System.out.print("Código do produto: ");
        int codigoProduto = scanner.nextInt();
        Produto produto = encontrarProduto(codigoProduto);
        if (produto != null) {
            System.out.print("Quantidade: ");
            int quantidade = scanner.nextInt();
            if (quantidade <= produto.getQuantidadeEstoque()) {
                double precoUnitario = produto.getPrecoUnitario();
                pedidos.add(new Pedido(numeroPedido, codigoProduto, precoUnitario, quantidade));
                produto.atualizarEstoque(quantidade);
                System.out.println("Pedido realizado com sucesso!");
            } else {
                System.out.println("Quantidade em estoque insuficiente.");
            }
        } else {
            System.out.println("Produto não encontrado.");
        }
    }

    private static void listarPedidos() {
        if (pedidos.isEmpty()) {
            System.out.println("Nenhum pedido realizado!");
        } else {
            for (Pedido pedido : pedidos) {
                System.out.println("Número: " + pedido.getNumeroPedido() + ", Código: " + pedido.getCodigoProduto() +
                        ", Preço: " + pedido.getPrecoUnitario() + ", Quantidade: " + pedido.getQuantidade());
            }
        }
    }

    private static void carregarPedidos() {
        try (BufferedReader reader = new BufferedReader(new FileReader("pedidos.txt"))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                String[] partes = linha.split(";");
                int numeroPedido = Integer.parseInt(partes[0]);
                int codigoProduto = Integer.parseInt(partes[1]);
                double precoUnitario = Double.parseDouble(partes[2]);
                int quantidade = Integer.parseInt(partes[3]);
                pedidos.add(new Pedido(numeroPedido, codigoProduto, precoUnitario, quantidade));
            }
        } catch (IOException e) {
            System.out.println("Erro ao carregar pedidos: " + e.getMessage());
        }
    }

    private static void salvarPedidos() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("pedidos.txt"))) {
            for (Pedido pedido : pedidos) {
                writer.write(pedido.getNumeroPedido() + ";" + pedido.getCodigoProduto() + ";"
                        + pedido.getPrecoUnitario() + ";" + pedido.getQuantidade());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Erro ao salvar pedidos: " + e.getMessage());
        }
    }
}
